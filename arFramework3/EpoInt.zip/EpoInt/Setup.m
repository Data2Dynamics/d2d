arInit;
arLoadModel('epo_int',1);
arLoadData('Epo_20070416_cpm',1);
arParseModel;
arWriteCFiles;
arLink;

arPrint;
arPlot;
arFit;
arTuner;
