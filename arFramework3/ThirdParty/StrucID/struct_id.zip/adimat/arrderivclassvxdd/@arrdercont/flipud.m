% This file is part of the ADiMat runtime environment
%
% Copyright 2011-2014 Johannes Willkomm 
%
function obj = flipud(obj)
  obj = flipdim(obj, 1);
end
% $Id: flipud.m 4344 2014-05-24 07:17:54Z willkomm $
