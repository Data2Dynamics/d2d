% This file is part of the ADiMat runtime environment
%
% Copyright (C) 2015 Johannes Willkomm 
%
function obj = acos(obj)
  obj = unopFlat(obj, @acos);
end
% $Id: acos.m 3862 2013-09-19 10:50:56Z willkomm $
