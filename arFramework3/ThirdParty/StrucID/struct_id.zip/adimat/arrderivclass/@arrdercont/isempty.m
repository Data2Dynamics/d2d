function r = isempty(obj)
  r = prod(obj.m_size) == 0;
end
