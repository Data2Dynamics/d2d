% This file is part of the ADiMat runtime environment
%
% Copyright 2011,2012,2013 Johannes Willkomm 
%
function obj = full(obj)
end
% $Id: full.m 4323 2014-05-23 09:17:16Z willkomm $
