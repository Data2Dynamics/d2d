% This file is part of the ADiMat runtime environment
%
% Copyright (C) 2015 Johannes Willkomm 
%
function obj = atan(obj)
  obj = unopFlat(obj, @atan);
end
% $Id: atan.m 3862 2013-09-19 10:50:56Z willkomm $
