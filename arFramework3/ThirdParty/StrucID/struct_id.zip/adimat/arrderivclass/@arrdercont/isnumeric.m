function z = isnumeric(obj)
  z = true();
