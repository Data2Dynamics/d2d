% This file is part of the ADiMat runtime environment
%
% Copyright 2015 Johannes Willkomm 
%
function n = ndims(obj)
  n = length(obj.m_size);
end
% $Id: ndims.m 4863 2015-02-07 15:37:52Z willkomm $
