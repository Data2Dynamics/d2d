function [obj] = cumtrapz(varargin)
  obj = adimat_cumtrapz(varargin{:});
end
