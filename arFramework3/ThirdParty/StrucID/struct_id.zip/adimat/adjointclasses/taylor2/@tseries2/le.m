function res = le(obj, v)
  res = cmpop(obj, v, @le);
end
