function obj = diff(obj, varargin)
  obj = adimat_diff(obj, varargin{:});
end
