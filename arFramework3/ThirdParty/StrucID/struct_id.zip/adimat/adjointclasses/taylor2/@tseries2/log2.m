function [obj] = log2(obj)
  obj = log(obj) ./ log(2);
end
