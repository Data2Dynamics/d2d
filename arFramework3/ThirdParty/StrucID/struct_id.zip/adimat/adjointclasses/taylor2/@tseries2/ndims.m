function res = ndims(obj)
  [res] = ndims(obj.m_series{1});
end
