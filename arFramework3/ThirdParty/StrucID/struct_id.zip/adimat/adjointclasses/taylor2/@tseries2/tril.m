function obj = tril(obj, varargin)
  obj = unopc(obj, @tril, varargin{:});
end
