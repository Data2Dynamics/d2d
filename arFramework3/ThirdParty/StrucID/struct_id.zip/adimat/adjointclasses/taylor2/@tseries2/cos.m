function obj = cos(obj)
  [~, obj] = sincos(obj);
end
