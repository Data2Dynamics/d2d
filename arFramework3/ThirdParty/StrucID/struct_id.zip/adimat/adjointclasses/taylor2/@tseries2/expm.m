function [obj] = expm(obj)
  obj = adimat_expm(obj);
end
