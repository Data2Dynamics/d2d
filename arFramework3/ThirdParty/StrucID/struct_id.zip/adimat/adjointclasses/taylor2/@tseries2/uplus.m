function obj = uplus(obj)
  obj = unop(obj, @uplus);
end
