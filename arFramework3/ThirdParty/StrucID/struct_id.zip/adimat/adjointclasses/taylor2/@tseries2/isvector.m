function r = isvector(obj)
  r = isvector(obj.m_series{1});
end
