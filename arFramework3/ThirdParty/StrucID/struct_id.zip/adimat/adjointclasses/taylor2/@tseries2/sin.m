function obj = sin(obj)
  [obj] = sincos(obj);
end
