function obj = sparse(obj)
  obj = unopc(obj, @sparse);
end
