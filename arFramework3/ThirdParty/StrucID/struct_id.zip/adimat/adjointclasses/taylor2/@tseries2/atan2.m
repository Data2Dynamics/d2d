function obj = atan2(y, x)
  obj = adimat_atan2(y, x);
end
