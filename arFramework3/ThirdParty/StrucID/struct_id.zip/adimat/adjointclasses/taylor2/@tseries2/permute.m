function obj = permute(obj, order)
  obj = unopV(obj, @permute, order);
end
