function obj = triu(obj, varargin)
  obj = unopc(obj, @triu, varargin{:});
end
