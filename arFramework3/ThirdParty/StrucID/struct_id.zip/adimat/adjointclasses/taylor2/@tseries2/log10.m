function [obj] = log10(obj)
  obj = log(obj) ./ log(10);
end
