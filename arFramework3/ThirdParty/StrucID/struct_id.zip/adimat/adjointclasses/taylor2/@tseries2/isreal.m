function res = isreal(obj)
  res = isreal(obj.m_series{1});
end
