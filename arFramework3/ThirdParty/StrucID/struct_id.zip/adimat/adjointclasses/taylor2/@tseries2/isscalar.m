function r = isscalar(obj)
  r = isscalar(obj.m_series{1});
end
