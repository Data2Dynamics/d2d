function obj = acsc(obj)
  obj = asin(1 ./ obj);
end
