function obj = unopc(obj, handle, varargin)
  obj = unopV(obj, handle, varargin{:});
end
