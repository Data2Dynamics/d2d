function obj = asec(obj)
  obj = acos(1 ./ obj);
end
