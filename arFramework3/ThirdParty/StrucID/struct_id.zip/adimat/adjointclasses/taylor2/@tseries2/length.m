function l = length(obj)
  l = max(size(obj));
end
