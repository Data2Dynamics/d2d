function obj = conj(obj)
  obj = unop(obj, @conj);
end
