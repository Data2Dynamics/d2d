function obj = diag(obj)
  obj = unopc(obj, @diag);
end
