function res = lt(obj, v)
  res = cmpop(obj, v, @lt);
end
