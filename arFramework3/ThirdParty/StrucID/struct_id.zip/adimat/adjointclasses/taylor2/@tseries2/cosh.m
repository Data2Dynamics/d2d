function obj = cosh(obj)
  [~, obj] = sinhcosh(obj);
end
