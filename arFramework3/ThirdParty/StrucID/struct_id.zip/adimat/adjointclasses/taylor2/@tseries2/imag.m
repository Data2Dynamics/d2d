function obj = imag(obj)
  obj = unop(obj, @imag);
end
