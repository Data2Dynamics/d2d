function res = eq(obj, v)
  res = cmpop(obj, v, @eq);
end
