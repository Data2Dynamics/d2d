function obj = ldivide(obj, right)
  obj = right / obj;
end
