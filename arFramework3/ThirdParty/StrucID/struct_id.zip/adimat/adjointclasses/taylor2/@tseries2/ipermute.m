function obj = ipermute(obj, order)
  obj = unopV(obj, @ipermute, order);
end
