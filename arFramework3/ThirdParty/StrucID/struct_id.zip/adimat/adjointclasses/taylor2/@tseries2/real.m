function obj = real(obj)
  obj = unop(obj, @real);
end
