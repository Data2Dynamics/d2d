function obj = bsxfun(handle, obj, right)
  obj = adimat_bsxfun(handle, obj, right);
end
