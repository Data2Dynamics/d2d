function obj = full(obj)
  obj = unopc(obj, @full);
end
