function obj = acot(obj)
  obj = atan(1 ./ obj);
end
