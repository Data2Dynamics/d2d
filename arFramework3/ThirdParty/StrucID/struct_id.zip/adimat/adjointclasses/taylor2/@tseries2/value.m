function val = value(obj)
  val = obj.m_series{1};
end
