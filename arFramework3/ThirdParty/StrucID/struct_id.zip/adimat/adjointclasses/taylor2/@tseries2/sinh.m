function obj = sinh(obj)
  [obj] = sinhcosh(obj);
end
