function res = ne(obj, v)
  res = cmpop(obj, v, @ne);
end
