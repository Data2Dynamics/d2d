function obj = uminus(obj)
  obj = unop(obj, @uminus);
end
