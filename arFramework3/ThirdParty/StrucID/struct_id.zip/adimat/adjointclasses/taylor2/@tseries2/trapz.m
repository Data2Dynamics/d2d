function [obj] = trapz(varargin)
  obj = adimat_trapz(varargin{:});
end
