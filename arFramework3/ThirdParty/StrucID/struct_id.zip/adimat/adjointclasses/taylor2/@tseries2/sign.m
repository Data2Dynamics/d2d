function res = sign(obj)
  [res] = sign(obj.m_series{1});
end
