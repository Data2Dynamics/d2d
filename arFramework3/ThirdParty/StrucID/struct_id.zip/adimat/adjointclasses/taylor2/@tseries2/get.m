function val = get(obj, name)
  val = option(name);
end
