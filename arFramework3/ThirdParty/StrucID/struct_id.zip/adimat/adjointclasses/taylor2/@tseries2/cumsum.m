function obj = cumsum(obj, varargin)
  obj = unopV(obj, @cumsum, varargin{:});
end
