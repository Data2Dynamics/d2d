function obj = transpose(obj)
  obj = unop(obj, @transpose);
end
