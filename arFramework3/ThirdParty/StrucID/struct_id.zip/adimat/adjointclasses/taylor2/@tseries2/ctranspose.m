function obj = ctranspose(obj)
  obj = unop(obj, @ctranspose);
end
