function obj = mrdivide(obj, right)
  obj = (right' \ obj')';
end
