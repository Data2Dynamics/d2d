function res = ge(obj, v)
  res = cmpop(obj, v, @ge);
end
