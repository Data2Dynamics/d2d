function [q r] = qr(obj)
  [q r] = adimat_qr(obj);
end
