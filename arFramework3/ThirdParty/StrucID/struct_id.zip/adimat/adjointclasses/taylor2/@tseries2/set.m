function obj = set(obj, name, val)
  option(name, val);
end
