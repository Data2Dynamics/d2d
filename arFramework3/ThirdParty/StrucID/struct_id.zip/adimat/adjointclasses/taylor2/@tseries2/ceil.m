function [res] = ceil(obj)
  res = ceil(obj.m_series{1});
end
