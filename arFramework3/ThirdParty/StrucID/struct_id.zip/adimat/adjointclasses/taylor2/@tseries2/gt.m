function res = gt(obj, v)
  res = cmpop(obj, v, @gt);
end
